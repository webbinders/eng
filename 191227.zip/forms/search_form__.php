
<form method="POST" class="search" action="./search_form_handling.php">
    <p>На английском</p>
    <p class="foreign_box">
         <input class="foreign_box" name="foreign_box[1]" size="" value="" type="">
    </p>
    <p class="foreign_box"> <input class="foreign_box" name="foreign_box[2]" size="" value="" type=""></p>
    <p class="foreign_box"> <input class="foreign_box" name="foreign_box[3]" size="" value="" type=""></p>
    <p>Искать как фрагмент</p>
    <p><input name="asPart_chb[1]" value="" checkbox="" type="checkbox"></p>
    <p><input name="asPart_chb[2]" value="" checkbox="" type="checkbox"></p>
    <p><input name="asPart_chb[3]" value="" checkbox="" type="checkbox"></p>
    <p class="">На русском <input class="" name="native_box" size="" value="" type=""></p>
    <button id="" formaction="" class="" name="btnFind">Найти</button>
</form>